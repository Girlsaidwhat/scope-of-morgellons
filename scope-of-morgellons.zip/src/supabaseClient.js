import { createClient } from '@supabase/supabase-js'

export const supabase = createClient(
  'https://yaxkujoiqmsixougkkdu.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlheGt1am9pcW1zaXhvdWdra2R1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyNTk4MjksImV4cCI6MjA2NzgzNTgyOX0.rAvWAdXuy9KR7efCMZ_dWNv0idE-DQkcsawX60WkZkA'
)
